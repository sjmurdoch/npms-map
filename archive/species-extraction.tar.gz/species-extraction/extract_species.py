"""Extract the NPMS indicator species list from the scheme's Species Identification Guide.

The guide encodes, for every species, the habitats it is an indicator for. Those are
drawn as pictogram icons rather than text, so they are recovered by rendering each
icon and matching it against the eleven reference icons on the guide's key page.
Everything else - names, difficulty class, Wildflower-level flag, flowering months,
field notes - comes straight out of the page's text and vector objects.

Output: species.js, consumed by the field app for its per-habitat recording lists.

    uv run --with pdfplumber --with pillow --with numpy python extract_species.py
"""
import json, re, subprocess, sys, tempfile
from pathlib import Path

import numpy as np
import pdfplumber
from PIL import Image

GUIDE = Path(sys.argv[1] if len(sys.argv) > 1 else "../../NPMS_Id guide_WEB_2ndEd.pdf")
OUT = Path(__file__).resolve().parent.parent / "species.js"

DPI = 300
RENDER_CACHE = Path(tempfile.gettempdir()) / "npms-guide-render"
PT = DPI / 72.0
KEY_PAGE = 1                      # 0-based: the "Key" spread with the habitat legend
NAME_FONT = "BoldItalic"
NAME_SIZE = 11.5
ICON_DY = 27.6                    # icon design box top, below the scientific name's top
ICON_BOX = 9.9                    # icon design box side, in points

ORANGE = (0.891, 0.558, 0.101)    # flowering month / Wildflower badge fill
TRAFFIC = {"G": "easy", "A": "harder", "R": "confusable"}

# Short keys for the eleven broad habitats, in key-page order.
HABITAT_KEYS = ["woodland", "pinewood", "arable", "lowland-grass", "upland-grass",
                "heath", "bog", "marsh", "freshwater", "rock", "coast"]

# The guide draws lowland and upland grassland with the same pictogram - they are
# vector-identical in the key - so the two cannot be told apart from the icons and
# are reported as one grassland class.
MERGE = {"upland-grass": "lowland-grass"}
LABEL_OVERRIDE = {"lowland-grass": "Lowland & upland grassland",
                  "woodland": "Broadleaved woodland, hedges & scrub"}


def close(a, b, tol=0.02):
    return all(abs(x - y) <= tol for x, y in zip(a, b))


def render(pdf_path, pages, outdir):
    """Render 1-based page numbers to PNG, returning {page: PIL.Image}."""
    imgs = {}
    for p in pages:
        stem = outdir / f"p{p}"
        if not (sorted(outdir.glob(f"p{p}-*.png")) or sorted(outdir.glob(f"p{p}.png"))):
            subprocess.run(["pdftoppm", "-png", "-r", str(DPI), "-f", str(p), "-l", str(p),
                            str(pdf_path), str(stem)], check=True)
        hit = sorted(outdir.glob(f"p{p}-*.png")) or sorted(outdir.glob(f"p{p}.png"))
        imgs[p] = Image.open(hit[0]).convert("RGB")
    return imgs


def crop(img, x_pt, top_pt, pad=0):
    x0 = int(round(x_pt * PT)) - pad
    y0 = int(round(top_pt * PT)) - pad
    side = int(round(ICON_BOX * PT)) + 2 * pad
    return img.crop((x0, y0, x0 + side, y0 + side))


def signature(im, n=20):
    return np.asarray(im.resize((n, n), Image.LANCZOS), dtype=np.float32) / 255.0


def rows_of_icons(page, name_top):
    """Icon design-box positions for the entry whose scientific name starts at name_top."""
    band = [c for c in page.curves
            if c["x0"] > 250 and 9.0 < c["width"] < 11.0
            and name_top + 20 < c["top"] < name_top + 40]
    if not band:
        return []
    # A full-height icon pins the design box; otherwise fall back to the fixed offset.
    full = [c["top"] for c in band if c["height"] > 9.5]
    top = min(full) if full else name_top + ICON_DY
    xs = []
    for c in sorted(band, key=lambda c: c["x0"]):
        if not xs or c["x0"] - xs[-1] > 3:
            xs.append(c["x0"])
    return [(x, top) for x in xs]


def reference_icons(pdf, imgs):
    page = pdf.pages[KEY_PAGE]
    labels = [w for w in page.extract_words()
              if w["x0"] > 258 and 355 < w["top"] < 530]
    tops = []
    for w in sorted(labels, key=lambda w: w["top"]):
        if not tops or w["top"] - tops[-1] > 5:
            tops.append(w["top"])
    assert len(tops) == 11, f"expected 11 habitat labels, got {len(tops)}"
    icons = [c for c in page.curves if c["x0"] > 240 and 9.0 < c["width"] < 11.0]
    refs = []
    for i, t in enumerate(tops):
        near = [c for c in icons if t - 4 < c["top"] < t + 10]
        full = [c["top"] for c in near if c["height"] > 9.5]
        box_top = min(full) if full else t - 1.45
        label = " ".join(w["text"] for w in labels if abs(w["top"] - t) < 3)
        refs.append((HABITAT_KEYS[i], signature(crop(imgs[KEY_PAGE + 1], near[0]["x0"], box_top)), label))
    return refs


def match_icon(img, x, top, refs):
    """Nearest reference icon, searching small offsets to absorb design-box jitter."""
    pad = 6
    win = np.asarray(crop(img, x, top, pad=pad), dtype=np.float32) / 255.0
    side = int(round(ICON_BOX * PT))
    best, best_d = None, 1e18
    for dy in range(0, 2 * pad + 1, 2):
        for dx in range(0, 2 * pad + 1, 2):
            sub = Image.fromarray((win[dy:dy + side, dx:dx + side] * 255).astype(np.uint8))
            if sub.size != (side, side):
                continue
            sig = signature(sub)
            for key, ref, _ in refs:
                d = float(np.mean((sig - ref) ** 2))
                if d < best_d:
                    best, best_d = key, d
    return best, best_d


def month_bands(page):
    """Tops of the twelve-block flowering-month strips on a page, one per entry."""
    rows = {}
    for r in page.rects:
        if r["x0"] > 250 and 8.5 < r["width"] < 9.5 and 8.5 < r["height"] < 9.7:
            rows.setdefault(round(r["top"], 0), []).append(r)
    return sorted(t for t, v in rows.items() if len(v) == 12)


def month_flags(page, name_top):
    band = [r for r in page.rects
            if r["x0"] > 250 and 8.5 < r["width"] < 9.5
            and name_top + 33 < r["top"] < name_top + 46]
    band.sort(key=lambda r: r["x0"])
    if len(band) != 12:
        return None
    return "".join("1" if close(r.get("non_stroking_color") or (), ORANGE) else "0" for r in band)


def has_wf(page, name_top):
    for c in page.curves:
        if (c["x0"] > 355 and 12.0 < c["width"] < 15.0 and 17.0 < c["height"] < 22.0
                and name_top - 4 < c["top"] < name_top + 20
                and close(c.get("non_stroking_color") or (), ORANGE)):
            return True
    return False


# The guide sets each entry as a lead description followed by two optional
# sub-headed blocks, both run together by plain text extraction.
NOTE_HEADS = ("LEAVES AND STEMS", "CONFUSED WITH")


def split_notes(text):
    out = {}
    rest = text
    for head in reversed(NOTE_HEADS):
        i = rest.find(head)
        if i < 0:
            continue
        out[head], rest = rest[i + len(head):].strip(), rest[:i].strip()
    return rest, out.get("LEAVES AND STEMS", ""), out.get("CONFUSED WITH", "")


def section_of(page):
    heads = [c for c in page.chars if abs(c["top"] - 20.0) < 1.5 and 9.5 < c["size"] < 11.5]
    if not heads:
        return None
    return "".join(c["text"] for c in sorted(heads, key=lambda c: c["x0"])).strip()


def text_lines(page, size, lo, hi, xmin=0, drop=None):
    """Text at a given point size within a vertical band, one string per line.

    `drop` masks out a rectangle - used to keep the flowering-month letters, which
    are set at the same size as the field notes, out of the notes.
    """
    lines = {}
    for c in page.chars:
        if drop and c["x0"] > drop[0] and drop[1] <= c["top"] < drop[2]:
            continue
        if abs(c["size"] - size) < 0.35 and lo <= c["top"] < hi and c["x0"] >= xmin:
            lines.setdefault(round(c["top"], 0), []).append(c)
    out = []
    for t in sorted(lines):
        out.append("".join(ch["text"] for ch in sorted(lines[t], key=lambda ch: ch["x0"])))
    return out


def main():
    pdf = pdfplumber.open(GUIDE)
    npages = len(pdf.pages)

    # Pages carrying species entries: any page with a bold-italic 11.5pt name.
    species_pages = []
    entries_by_page = {}
    for i, page in enumerate(pdf.pages):
        names = [c for c in page.chars
                 if NAME_FONT in c["fontname"] and abs(c["size"] - NAME_SIZE) < 0.3]
        if not names:
            continue
        tops = []
        for t in sorted({round(c["top"], 1) for c in names}):
            if not tops or t - tops[-1][-1] > 3:
                tops.append([t])
            else:
                tops[-1].append(t)
        # A wrapped name occupies two lines ~13pt apart: treat as one entry.
        groups = []
        for g in tops:
            t = g[0]
            if groups and t - groups[-1][-1] < 20:
                groups[-1].append(t)
            else:
                groups.append([t])
        # One entry - "Conifer seedlings and saplings" - is a recording category
        # with no scientific name. Anchor any such entry off its flowering-month
        # band, which every entry carries.
        for top in month_bands(page):
            if not any(top - 46 < g[-1] < top - 30 for g in groups):
                groups.append([top - 39.4])
        groups.sort()
        entries_by_page[i] = groups
        species_pages.append(i)

    if True:
        td = Path(RENDER_CACHE); td.mkdir(parents=True, exist_ok=True)
        want = sorted({KEY_PAGE + 1} | {p + 1 for p in species_pages})
        print(f"rendering {len(want)} pages at {DPI} dpi…", file=sys.stderr)
        imgs = render(GUIDE, want, td)
        refs = reference_icons(pdf, imgs)

        species, worst = [], 0.0
        for pi in species_pages:
            page = pdf.pages[pi]
            sect = section_of(page)
            groups = entries_by_page[pi]
            bounds = [g[0] for g in groups] + [page.height]
            for gi, g in enumerate(groups):
                first, last = g[0], g[-1]
                sci = " ".join(text_lines(page, NAME_SIZE, first - 1, last + 6)).strip()
                sci = re.sub(r"\s+", " ", sci)
                below = last + 6
                common = text_lines(page, NAME_SIZE, below, below + 20)
                letter = "".join(text_lines(page, 11.0, first - 2, first + 18, xmin=330))
                letter = next((ch for ch in letter if ch in TRAFFIC), None)
                notes = text_lines(page, 8.5, last + 20, bounds[gi + 1] - 5, xmin=20,
                                   drop=(265, last + 33, last + 46))
                notes = split_notes(re.sub(r"\s+", " ", " ".join(notes)).strip())
                habs = []
                for x, top in rows_of_icons(page, last):
                    key, d = match_icon(imgs[pi + 1], x, top, refs)
                    worst = max(worst, d)
                    key = MERGE.get(key, key)
                    if key and key not in habs:
                        habs.append(key)
                habs.sort(key=HABITAT_KEYS.index)
                species.append({
                    "sci": sci,
                    "common": (common[0].strip() if common else ""),
                    "diff": letter or "",
                    "wf": has_wf(page, first),
                    "months": month_flags(page, last) or "",
                    "habitats": habs,
                    "group": sect or "",
                    "page": pi + 1,
                    "notes": notes[0],
                    "leaves": notes[1],
                    "confused": notes[2],
                })

    print(f"{len(species)} entries, worst icon match distance {worst:.4f}", file=sys.stderr)
    habitats = []
    for key, _, label in refs:
        if key in MERGE:
            continue
        habitats.append({"key": key, "label": LABEL_OVERRIDE.get(key, label)})
    payload = {"habitats": habitats, "species": species}
    OUT.write_text("// Generated by tools/extract_species.py from the NPMS Species\n"
                   "// Identification Guide (2nd ed). Do not edit by hand.\n"
                   "const SPECIES = " + json.dumps(payload, ensure_ascii=False,
                                                   separators=(",", ":")) + ";\n")
    print(f"wrote {OUT} ({OUT.stat().st_size // 1024} KB)", file=sys.stderr)


if __name__ == "__main__":
    main()
