# NPMS species list extraction — archived, not used by the app

This is finished, verified work that the field app does **not** load. It is kept here so it is not lost, and nothing in `index.html`, `app.js` or `sw.js` references it. Unpacking this archive does not change the app; wiring it in would be a deliberate piece of work.

## What it is

`species.js` holds 410 entries extracted from the NPMS *Species Identification Guide* (2nd edition, 2019, 168 pages). Each entry carries:

| Field | Meaning |
|---|---|
| `sci` | Scientific name, with the guide's bracketed synonyms where it gives them. Empty for the one entry that has no scientific name, "Conifer seedlings and saplings". |
| `common` | English name |
| `diff` | The guide's traffic light: `G` easy (138), `A` harder (225), `R` confusable (46) |
| `wf` | On the Wildflower-level list (217 of 410) |
| `months` | Twelve characters, `1` where the guide highlights that flowering month |
| `habitats` | Broad habitats the species indicates, as keys (see below) |
| `group` | The guide's colour/shape section — 14 of them, e.g. "White / Cream", "Grasses", "Sedges" |
| `page` | Page in the guide PDF, for looking up the photograph |
| `notes`, `leaves`, `confused` | The entry's lead description, its "LEAVES AND STEMS" block, and its "CONFUSED WITH" block |

Habitat keys and their spread: `lowland-grass` 142, `coast` 112, `woodland` 76, `freshwater` 58, `marsh` 54, `rock` 54, `heath` 49, `bog` 49, `arable` 30, `pinewood` 28.

## How the habitats were recovered

The guide encodes each species' habitats as small pictogram icons, not text. `extract_species.py` renders every page at 300 dpi, crops each icon from its design box, and matches it against the eleven reference icons on the guide's key page. Names, difficulty letter, Wildflower badge and flowering months come from the page's text and vector objects directly.

Match quality across all 666 icons: median distance 0.0076, 95th percentile 0.0182, worst 0.0445, against a nearest-neighbour separation between distinct reference icons of 0.0181 or more — except for one pair, below. Spot checks against known ecology all came out right: Ramsons → woodland; Water-plantain → freshwater; Stinking Chamomile → arable; Heather → heathland, bog, pinewood, grassland, coast; Dog's Mercury → woodland, rock; Thrift → grassland, coast.

## Known limitation

**Lowland and upland grassland cannot be told apart.** The guide draws them with the same pictogram — the two icons in its own key are vector-identical, the same four paths at the same sizes and colours. A species in both grasslands simply shows the icon twice. The extractor therefore merges them into one `lowland-grass` class labelled "Lowland & upland grassland". For a lowland square this costs nothing much; an upland-only species will appear in a lowland list.

## Regenerating

Needs the source PDF, which is not in the repo (`*.pdf` is gitignored) because it is licensed NPMS material. The script defaults to `../../NPMS_Id guide_WEB_2ndEd.pdf` relative to itself and writes `species.js` to its parent directory; pass the PDF path as the first argument if it sits elsewhere. Renders are cached in the system temp directory, so a re-run after the first takes seconds rather than minutes.

```
uv run --with pdfplumber --with pillow --with numpy python extract_species.py [path/to/guide.pdf]
```

Requires `pdftoppm` from poppler.

## Licence

Species names, difficulty classes, flowering times, habitat lists and field notes are the National Plant Monitoring Scheme's (BSBI, CEH, JNCC, Plantlife). This extraction is for the survey volunteer's own use, in the same spirit as the rest of this repository, and is not a redistribution.
